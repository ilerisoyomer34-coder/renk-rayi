// Renk Rayı service worker (otomatik üretildi; elle düzenleme)
const CACHE = "renkrayi-flat-dea350f4f0";
const FILES = ["./","index.html","manifest.webmanifest","apple-touch-icon.png","favicon-32.png","icon-192.png","icon-512.png","maskable-192.png","maskable-512.png"];
self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(FILES.map(f => new Request(f, { cache: 'reload' })))));
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k.startsWith('renkrayi-') && k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('message', e => { if (e.data === 'skipWaiting') self.skipWaiting(); });
// önce önbellek: oyun tamamen internetsiz çalışır; önbellekte olmayan istekler ağdan gelir
self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET' || new URL(req.url).origin !== location.origin) return;
  e.respondWith(caches.match(req, { ignoreSearch: true }).then(hit => {
    if (hit) return hit;
    return fetch(req).catch(() => req.mode === 'navigate' ? caches.match('index.html') : Response.error());
  }));
});
